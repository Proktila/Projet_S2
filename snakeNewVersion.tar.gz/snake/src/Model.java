class Model {
}

class Score{

}

class Serpent{

}

class Maquette{

}